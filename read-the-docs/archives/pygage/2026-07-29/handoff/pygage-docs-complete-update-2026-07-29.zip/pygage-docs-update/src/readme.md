### base core code
